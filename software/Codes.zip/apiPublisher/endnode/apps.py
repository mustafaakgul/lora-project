from django.apps import AppConfig


class EndnodeConfig(AppConfig):
    name = 'endnode'

from django.contrib import admin
from .models import Endnode

admin.site.register(Endnode)

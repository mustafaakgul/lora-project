from django.apps import AppConfig

class GatewayapiConfig(AppConfig):
    name = 'gatewayApi'

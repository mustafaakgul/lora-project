from django.apps import AppConfig


class LoraapiConfig(AppConfig):
    name = 'LoraAPI'
